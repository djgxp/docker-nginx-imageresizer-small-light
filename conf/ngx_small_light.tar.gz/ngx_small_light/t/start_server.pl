use strict;
use warnings;
use t::Util;

my $nginx = t::Util->nginx_start;

while ( 1 ) {
    sleep(1);
}
